#include<stdio.h>
#include<stdlib.h>
#define size 5

int data[size];
int temp;
int list_filled=0;
int indexx=0;

 void Infront(int insert_data){
 	int i;
   if(list_filled==size){
   	printf("list full");
   }else{
   
    for(i=size;i>=0;i--)
	{
	  if(data[i-1]==0){
	  	
	  }else{
	  
	  data[i]=data[i-1];
    }}
    data[0]=insert_data;
    list_filled++;
	}
 }
 
 void Inlast(int insert_data){
 	if(list_filled==size){
   	printf("list full");
   }else{
   
    data[size-1]=insert_data;
    list_filled++;

 	
 }}
void Inmiddle(int insert_data){
	int i;
   if(list_filled==size){
   	printf("list full");
   }else{
   
    for(i=size;i>=indexx;i--)
	{
	  if(data[i-1]==0){
	  	
	  }else{
	  data[i]=data[i-1];
    }}
    data[indexx]=insert_data;
    list_filled++;
	}
}
void Display(){
	for(int i=0;i<size;i++){
		printf("%d\n",data[i]);
	}
}

void main(){
	int op;
	start:
	printf("enter operation\n 1==>Insert Data in front\n 2==>Insert Data in back\n 3==>Insert Data in middle\n\n 4==>Display Data\n");
	scanf("%d",&op);
	switch(op){
		case 1:
			printf("enter data\n");
			scanf("%d",&op);
			Infront(op);
			goto start;
		break;
	
	case 2:
			printf("enter data\n");
			scanf("%d",&op);
			Inlast(op);
			goto start;
		break;
	
	case 3:
			printf("enter data and the index\n");
			scanf("%d%d",&op,&indexx);
			Inmiddle(op);
			goto start;
		break;
	
	case 4:
		Display();
		goto start;
		break;

	default:
	printf("wrong choice");
}}