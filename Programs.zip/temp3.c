#include <stdio.h>
#define size 5
int item [size];
int f=-1;
int r=-1;
 
void Enqueue(int val){
	if(f==(r+1)%size){
		printf("Queue is full\n");
	}
	else{
		 if (f == -1) {
        f = 0;
    }
		  r=(r+1)%size;
 
			item[r]=val;
			printf("Data inserted successfully\n");
		}
		}
void Dequeue(){
 
	if(f==-1||r==-1){
		printf("Queue is empty\n");
	}
	else{
		int del=item[f];
	    f=(f+1)%size;
		printf("Data deleted is %d\n",del);
	}
}
void Display(){
    if(f == -1 || r==-1){  
        printf("Queue is empty\n");
    }
    else{
//    	if(f==-1){
//    		f=0;
//		}
 
        for (int i = f; i != r; i = (i + 1) % size) {
            printf("%d\n", item[i]);
        }
 
        printf("%d\n", item[r]);
    }
}
 
 
int main(){
	printf("Reyush Bhandari\n\n\n\n");
	printf("1=====>Enqueue\n");
	printf("2=====>Dequeue\n");
	printf("3=====>Display\n");
	int val,ch;
	START:
	printf("Enter your choice\n");
	scanf("%d",&ch);
	switch(ch){
		case 1:
			printf("Enter the value\n");
			scanf("%d",&val);
			Enqueue(val);
			break;
 
			case 2:
			Dequeue();
			break;
 
		case 3:
			Display();
			break;
 
 
 
		default:
			printf("Invalid choice");
			break;
		}
 
			printf("Press 5 to continue and 8 to exit");
		    int i;
		    scanf("%d",&i);
			if(i==5){
				goto START;
			}
			else{
				printf("Exit");
			}
 
	return 0;
}