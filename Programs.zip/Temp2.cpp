#include <iostream>
#include <fstream>

using namespace std; 

int main() {

    // open a text file for reading
    ifstream file_to_read("std_data.txt");

    string lines_of_file;

    // loop until the end of the text file
    while (!file_to_read.eof()) {

        getline(file_to_read, lines_of_file);

        // print the line variable
        cout << lines_of_file << endl;
    }

    // close the file
    file_to_read.close();

    return 0;
}

