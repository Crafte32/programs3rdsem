//Linear doubly

#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node *next, *prev;
};
struct Node* head = NULL;

// Insert at Beginning
void InsertAtBeginning(int val) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    newNode->data = val;
    newNode->next = head;
    newNode->prev = NULL;
    if (head != NULL)
        head->prev = newNode;
    head = newNode;
}

// Insert at End
void InsertAtEnd(int val) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
        return;
    }
    struct Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

// Insert at Random Position
void InsertAtPosition(int val, int pos) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    newNode->data = val;
    
    if (pos == 1) {
        InsertAtBeginning(val);
        return;
    }
    struct Node* temp = head;
    for (int i = 1; i < pos - 1; i++) {
        if (temp == NULL) {
            printf("Position out of range!\n");
            free(newNode);
            return;
        }
        temp = temp->next;
    }
    newNode->next = temp->next;
    newNode->prev = temp;
    if (temp->next!=NULL)
        temp->next->prev = newNode;
    temp->next = newNode;
}

// Delete at Beginning
void DeleteAtBeginning() {
    struct Node *delnode;
    if (head == NULL) {
        printf("List is empty!\n");
        return;
    } else if (head->next == NULL) {
        free(head);
        head = NULL;
    } else {
        delnode = head;
        head = head->next;
        head->prev = NULL;
        free(delnode);
    }
}

// Delete at End
void DeleteAtEnd() {
    if (head == NULL) {
        printf("List is empty!\n");
        return;
    }
    struct Node* temp = head;
    if (temp->next == NULL) {
        free(head);
        head = NULL;
        return;
    }
    while (temp->next)
        temp = temp->next;
    temp->prev->next = NULL;
    free(temp);
}

// Delete at Random Position
void DeleteAtPosition(int pos) {
    if (head == NULL) {
        printf("List is empty!\n");
        return;
    }
    struct Node* temp = head;
    for (int i = 1; i < pos - 1; i++) {
        if (temp == NULL) {
            printf("Position out of range!\n");
            return;
        }
        temp = temp->next;
    }
    struct Node* delNode = temp->next;
    if (delNode == NULL) {
        printf("Position out of range!\n");
        return;
    }
    temp->next = delNode->next;
    if (delNode->next)
        delNode->next->prev = temp;
    free(delNode);
}

// Display List
void Display() {
    struct Node* temp = head;
    if (head == NULL) {
        printf("List is empty!\n");
        return;
    }
    printf("List: ");
    while (temp!=NULL) {
        printf("%d\t", temp->data);
        temp = temp->next;
    }
}

// Main function with switch case
int main() {
    int choice, val, pos;
    printf("Reyush Bhandari\n");
    while (1) {
        printf("\n1. Insert at Beginning\n2. Insert at End\n3. Insert at Position\n");
        printf("4. Delete from Beginning\n5. Delete from End\n6. Delete from Position\n");
        printf("7. Display List\n8. Exit\nEnter choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &val);
                InsertAtBeginning(val);
                break;
            case 2:
                printf("Enter value: ");
                scanf("%d", &val);
                InsertAtEnd(val);
                break;
            case 3:
                printf("Enter value: ");
                scanf("%d", &val);
                printf("Enter position: ");
                scanf("%d", &pos);
                InsertAtPosition(val, pos);
                break;
            case 4:
                DeleteAtBeginning();
                break;
            case 5:
                DeleteAtEnd();
                break;
            case 6:
                printf("Enter position: ");
                scanf("%d", &pos);
                DeleteAtPosition(pos);
                break;
            case 7:
                Display();
                break;
            case 8:
                return 0;
            default:
                printf("Invalid choice!\n");
        }
    }
}