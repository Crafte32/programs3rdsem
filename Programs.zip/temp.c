#include<stdio.h>
#include<stdlib.h>
#define size 5
int item[size];
int f=-1;
int r=-1;
int Enqueue(int val){
	if(r==size-1){
	printf("Queue is full");
	}
	else{
	if(f==-1){
		f=0;
		}
		r++;
		item[r]=val;
		printf("Data inserted successfully:%d \n",item[r]);
	
}

}
int Dequeue(){
	if(f==-1|| r==-1){
	printf("Queue is empty");
	}
	else{
		int temp=item[f];
		f++;
		if(f>r){
			f=-1;
			r=-1;
		
		}
		printf("Data deleted is %d",temp);	
	}  
	
}
void display(){
	if (f==-1||r==-1){
		printf("Queue is empty");
		}
		else{
			for(int i=f;i<=r;i++){
				printf("%d\n",item[i]);
			}
		}
}
int main(){
    printf("Reyush Bhandari \n");
	int ch,val;
	printf("--------Choose Desired Function--------\n");
	printf("\n1.Enqueue\n2.Dequeue\n3.Display\n");
	START:
	printf("enter the choice    ");
	scanf("%d",&ch);
	switch(ch){
		case 1:
	        printf("enter the value    ");
			scanf("%d",&val);
			 Enqueue(val);
			break;
		case 2:
		     Dequeue();
		    break;
		case 3:
			 display();
			break;
		default:
			printf("Invalid Choice");
			break;
		}
		printf("Enter 5 to continue and 6 to discard   ");
		int i;
		scanf("%d",&i);
		if(i==5){
			goto START;
		}
		else{
			printf("exit");
		}
	}