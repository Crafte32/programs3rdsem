//circular doubly

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
};

struct Node* head = NULL;

void insertAtBeginning(int val) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Cannot allocate memory.\n");
        return;
    }

    newNode->data = val;
    if (head == NULL) {
        newNode->next = newNode;
        newNode->prev = newNode;
        head = newNode;
    } else {
        struct Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    printf("%d inserted at the beginning.\n", val);
}

void insertAtEnd(int val) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Cannot allocate memory.\n");
        return;
    }

    newNode->data = val;
    if (head == NULL) {
        newNode->next = newNode;
        newNode->prev = newNode;
        head = newNode;
    } else {
        struct Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
        newNode->next = head;
        head->prev = newNode;
    }
    printf("%d inserted at the end.\n", val);
}

void insertAtRandom(int val, int pos) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    struct Node* temp = head;
    int i;

    if (newNode == NULL) {
        printf("Cannot allocate memory.\n");
        return;
    }

    if (pos == 1) {
        insertAtBeginning(val);
        return;
    }

    for (i = 1; i < pos - 1; i++) {
        if (temp->next == head) {
            printf("Invalid position.\n");
            return;
        }
        temp = temp->next;
    }

    newNode->next = temp->next;
    newNode->prev = temp;
    temp->next->prev = newNode;
    temp->next = newNode;
    newNode->data = val;
    printf("%d inserted at position %d.\n", val, pos);
}

void deleteAtBeginning() {
    struct Node* temp = head;
    struct Node* delNode = head;

    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    if (head->next == head) { // Only one node
        free(delNode);
        head = NULL;
    } else {
        temp = head->prev; // Last node
        temp->next = head->next;
        head->next->prev = temp;
        head = head->next;
        free(delNode);
    }
    printf("Node deleted at the beginning.\n");
}

void deleteAtEnd() {
    struct Node* temp = head;
    struct Node* delNode;

    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    if (head->next == head) { // Only one node
        delNode = head;
        head = NULL;
        free(delNode);
    } else {
        while (temp->next != head) {
            temp = temp->next;
        }
        delNode = temp;
        temp->prev->next = head;
        head->prev = temp->prev;
        free(delNode);
    }
    printf("Node deleted at the end.\n");
}

void deleteAtRandom(int pos) {
    struct Node* temp = head;
    struct Node* delNode;
    int i;

    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    if (pos == 1) {
        deleteAtBeginning();
        return;
    }

    for (i = 1; i < pos - 1; i++) {
        if (temp->next == head) {
            printf("Invalid position.\n");
            return;
        }
        temp = temp->next;
    }

    delNode = temp->next;
    temp->next = delNode->next;
    delNode->next->prev = temp;
    free(delNode);
    printf("Node deleted at position %d.\n", pos);
}

void display() {
    struct Node* temp;
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }
    temp = head;
    printf("List elements:\n");
    while (temp!= head);
        printf("%d\t", temp->data);
        temp = temp->next;
    printf("\n");
}

int main() {
    int choice, val, pos;
    printf("Reyush Bhandari\n");
    while (1) {
        printf("\n1-------> Insert at Beginning\n");
        printf("2-------> Insert at End\n");
        printf("3-------> Insert at Random Position\n");
        printf("4-------> Delete at Beginning\n");
        printf("5-------> Delete at End\n");
        printf("6-------> Delete at Random Position\n");
        printf("7-------> Display the List\n");
        printf("8-------> Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert at beginning: ");
                scanf("%d", &val);
                insertAtBeginning(val);
                break;
            case 2:
                printf("Enter value to insert at end: ");
                scanf("%d", &val);
                insertAtEnd(val);
                break;
            case 3:
                printf("Enter value to insert: ");
                scanf("%d", &val);
                printf("Enter position to insert: ");
                scanf("%d", &pos);
                insertAtRandom(val, pos);
                break;
            case 4:
                deleteAtBeginning();
                break;
            case 5:
                deleteAtEnd();
                break;
            case 6:
                printf("Enter position to delete: ");
                scanf("%d", &pos);
                deleteAtRandom(pos);
                break;
            case 7:
                display();
                break;
            case 8:
                printf("Exiting program.\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}