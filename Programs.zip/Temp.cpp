#include <iostream>
#include <fstream>

using namespace std;

int main() {

    // open a text file for writing
    ofstream file_to_open("example.txt",ios::app);


    // Write to file
    file_to_open << "Ram" << endl;
    

    // close the file
    file_to_open.close();

    return 0;
}
