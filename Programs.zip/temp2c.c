#include<stdio.h>
#include<stdlib.h>
#define size 50

int data[size];
int temp;
int list_filled=0;
int indexx=0;

 void Infront(int insert_data){
 	system("cls");
 	int i;
   if(list_filled==size){
   	printf("list full");
   }else{
   
    for(i=size;i>=0;i--)
	{
	  if(data[i-1]==0){
	  	
	  }else{
	  
	  data[i]=data[i-1];
    }}
    data[0]=insert_data;
    list_filled++;
	}
 }
 
 void Inlast(int insert_data){
 	system("cls");
 	if(list_filled==size){
   	printf("list full");
   }else{
   
    data[size-1]=insert_data;
    list_filled++;

 	
 }}
void Inmiddle(int insert_data){
	system("cls");
	int i;
   if(list_filled==size){
   	printf("list full");
   }else{
   
    for(i=size;i>=indexx;i--)
	{
	  if(data[i-1]==0){
	  	
	  }else{
	  data[i]=data[i-1];
    }}
    data[indexx]=insert_data;
    list_filled++;
	}
}
void Display(){
	system("cls");
	int a=0;
	for(int i=0;i<size;i++){
		a++;
		printf("%d  ",data[i]);
		switch(a){
			case 10:
				a=0;
				printf("\n");
		}
	}
}

void delete_beginning(){
	system("cls");
	data[size]=0;
	list_filled--;
}
void delete_end(){
	system("cls");
	data[0]=0;
	list_filled--;
}
void delete_any(int a){
	system("cls");
	data[a]=0;
}

void main(){
	int op;
	start:
	printf("Reyush Bhandari\n");
	printf("enter operation\n1====>insert data at beginning\n2====>insert data at end\n3====>insert data at random position\n4====>delete data at beginning\n5====>delete data at end\n6====>delete data at random\n7====>Display Data\n");
	scanf("%d",&op);
	switch(op){
		case 1:
			printf("enter data\n");
			scanf("%d",&op);
			Infront(op);
			goto start;
		break;
	
	case 2:
			printf("enter data\n");
			scanf("%d",&op);
			Inlast(op);
			goto start;
		break;
	
	case 3:
		again:
			printf("enter data and the index\n");
			scanf("%d%d",&op,&indexx);
			if(indexx>size-1){
				printf("index error ");
				goto again;
			}
			Inmiddle(op);
			goto start;
		break;
	
	case 7:
		Display();
		goto start;
		break;
	
	case 5:
		delete_beginning();
		break;
		
	case 6:
		delete_end();
		break;
		
	case 4:
		printf("enter the index to delete");
		scanf("%d",&op);
		delete_any(op);
		break;

	default:
	printf("wrong choice");
}}
