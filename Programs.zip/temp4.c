#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;


Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed.\n");
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}


void addAtBeginning(Node** head, int data) {
	system("cls");
    Node* newNode = createNode(data);
    newNode->next = *head; 
    *head = newNode;  
}


void addAtEnd(Node** head, int data) {
	system("cls");
    Node* newNode = createNode(data);
    
    if (*head == NULL) {
        *head = newNode;  
        return;
    }

    Node* temp = *head;
    while (temp->next != NULL) {
        temp = temp->next; 
    }
    temp->next = newNode;  
}


void deleteFromBeginning(Node** head) {
	system("cls");
    if (*head == NULL) {
        printf("List is empty. Cannot delete.\n");
        return;
    }
    
    Node* temp = *head;
    *head = (*head)->next;
    free(temp); 
}


void deleteFromEnd(Node** head) {
	system("cls");
    if (*head == NULL) {
        printf("List is empty. Cannot delete.\n");
        return;
    }

    if ((*head)->next == NULL) {
        free(*head);
        *head = NULL; 
        return;
    }

    Node* temp = *head;
    while (temp->next != NULL && temp->next->next != NULL) {
        temp = temp->next; 
    }

    free(temp->next); 
    temp->next = NULL; 
}

void displayList(Node* head) {
	int a=0;
	system("cls");
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }
    
    Node* temp = head;
    printf("Data: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
        switch(a){
        	case 10:
        		printf("\n");
        		a=0;
		}
    }
    printf("\n");
}


void freeList(Node* head) {
	system("cls");
    Node* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);  
    }
}

int main() {
    Node* head = NULL; 
    int choice, data;
    while (1) {
    	printf("Reyush Bhandari");
        printf("\n<====  === Functions === ====>\n");
        printf("1. Add data at beginning\n");
        printf("2. Add data at end\n");
        printf("3. Delete data at beginning\n");
        printf("4. Delete data at end\n");
        printf("5. Display data\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the data to add at the beginning: ");
                scanf("%d", &data);
                addAtBeginning(&head, data);
                break;
            case 2:
                printf("Enter the data to add at the end: ");
                scanf("%d", &data);
                addAtEnd(&head, data);
                break;
            case 3:
                deleteFromBeginning(&head);
                break;
            case 4:
                deleteFromEnd(&head);
                break;
            case 5:
                displayList(head);
                break;
            case 6:
                freeList(head);
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice! Please enter a valid option.\n");
        }
    }

    return 0;
}
