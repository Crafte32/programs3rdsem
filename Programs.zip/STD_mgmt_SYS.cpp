#include <iostream>
#include <fstream>
#include <conio.h>

using namespace std;
void case1(){
	int ag;
	int roll_no,symbol_no;
	string faculty,semester,full_name;
	
	ofstream file("std_data.txt",ios::app);
	again:
			cout<<"| --Enter name,roll,symbol,fac,sem- |\n";
			cin>>full_name>>roll_no>>symbol_no>>faculty>>semester;
			cout<<"|                                   |\n";
			cout<<"| - Data Inserted ! --------------- |\n";
			file<<full_name<<endl<<roll_no<<endl<<symbol_no<<endl<<faculty<<endl<<semester<<endl;
			
			cout<<"| --Enter 1 to add another data---- |\n";
			cin>>ag;
			if(ag==1){
				goto again;
			}
			file.close();
			
		
}

void case2(){
	string lines_of_file;
		ifstream file("std_data.txt");
			while (!file.eof()) {
			 getline(file, lines_of_file);
			 cout << lines_of_file << endl;
			 }
			 file.close();
			 

}

void case3(){
	string lines_of_file,name;
		ifstream fi("std_data.txt");
		cout<<"| --Enter the name of student------ |\n";
		cin>>name;
			while (!fi.eof()) {
			 getline(fi, lines_of_file);
			 if(lines_of_file==name){
			 cout << lines_of_file << endl;
			 for(int i=1;i<=4;i++){
			 getline(fi,lines_of_file);
			 cout << lines_of_file << endl;
			 }
			 }
			 }
			 fi.close();
			 
}

void case4(){
		ofstream fi("std_data.txt");
			fi<<"";
			fi.close();
			
}


int main() {
	int choice;
	start:
		
		system("cls");
		
	cout<<"| **************WELCOME************ |\n";
	cout<<"|                                   |\n";
	cout<<"| --Enter 1 to add info------------ |\n";
	cout<<"|                                   |\n";
	cout<<"| --Enter 2 to read all info------- |\n";
	cout<<"|                                   |\n";
	cout<<"| --Enter 3 to read specific info-- |\n";
	cout<<"|                                   |\n";
	cout<<"| --Enter 4 to delete all data----- |\n";
	cout<<"|                                   |\n";
    cout<<"| ***Press any other key to exit*** |\n";
	cout<<endl;
	cin>>choice;	
	
	switch (choice){
		case 1:
			case1();
			goto start;
			break;
			
		case 2:
			case2();
			goto start;
			break;
		case 3:
			case3();
			goto start;
			break;
			
		case 4:
			case4();
			goto start;
			break;
		
		
		default:
			cout<<"\n| **************Exited************* |\n";
	}
    return 0;
}
