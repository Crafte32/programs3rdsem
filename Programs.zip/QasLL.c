//queue as linked list

#include <stdio.h>
#include <stdlib.h>

// Structure for a Node
struct Node {
    int data;
    struct Node* next;
};

typedef struct Node Node;
Node* front = NULL;
Node* rear = NULL;

// Function to enqueue (insert) an element into the queue
void enqueue(int val) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return;
    }
    newNode->data = val;
    newNode->next = NULL;

    if (front == NULL) {
        front = newNode;
        rear = newNode;
    } else {
        rear->next = newNode;
        rear = newNode;
    }
}

// Function to dequeue (remove) an element from the queue
void dequeue() {
    if (front == NULL) {
        printf("Queue is empty\n");
    } else {
        Node* delNode = front;
        front = front->next;
        printf("Deleted data is: %d\n", delNode->data);
        free(delNode);
        if (front == NULL) {
            rear = NULL; // Reset rear when queue becomes empty
        }
    }
}

// Function to display the queue elements
void display() {
    if (front == NULL) {
        printf("Queue is empty\n");
        return;
    }
    Node* temp = front;
    printf("Queue elements:\n");
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

// Main function with switch case for menu-driven program
int main() {
    int choice, val;
    printf("Reyush Bhandari\n");
    while (1) {
        printf("\nQueue Menu:\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to enqueue: ");
                scanf("%d", &val);
                enqueue(val);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4:
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }
    return 0;
}